<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Crudmodel');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$record = $this->Crudmodel->getData();
		$this->load->view('welcome_message',['record'=>$record]);
	}
	public function create()
	{
		$this->load->view('create');
	}

	public function insert(){
		$employee = array(
			'first_name' => isset($_POST['first_name']) && !empty($_POST['first_name']) ? $_POST['first_name'] : '',
			'last_name' => isset($_POST['last_name']) && !empty($_POST['last_name']) ? $_POST['last_name'] : '',
			'email' => isset($_POST['email']) && !empty($_POST['email']) ? $_POST['email'] : '',
			'country_code' => isset($_POST['country_code']) && !empty($_POST['country_code']) ? $_POST['country_code'] : '',
			'phone' => isset($_POST['phone']) && !empty($_POST['phone']) ? $_POST['phone'] : '',
			'address' => isset($_POST['address']) && !empty($_POST['address']) ? $_POST['address'] : '',
			'gender' => isset($_POST['gender']) && !empty($_POST['gender']) ? $_POST['gender'] : '',
			'hobby' => isset($_POST['hobby']) && !empty($_POST['hobby']) ? implode(",",$_POST['hobby']) : '',
			// 'photo' => isset($_POST['photo']) && !empty($_POST['photo']) ? implode(",",$_POST['photo']) : '',
		);

		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'jpg|jpeg|png';
		$this->load->library('upload',$config);
		 
		
		if($this->upload->do_upload('photo')){
			$photoData=$this->upload->data();
			$employee['photo'] = $photoData['file_name'];
		}else{
			$employee['photo'] = '';
		}

		$query = $this->Crudmodel->Insertdata($employee);

		if($query){
			redirect(base_url());
		}
	}
	public function edit(){
		$id = $_GET['id'];
		$record = $this->Crudmodel->getEmpById($id);
		$this->load->view('update',['record'=>$record]);
	}
	public function update(){
		$employee = array(
			'first_name' => isset($_POST['first_name']) && !empty($_POST['first_name']) ? $_POST['first_name'] : '',
			'last_name' => isset($_POST['last_name']) && !empty($_POST['last_name']) ? $_POST['last_name'] : '',
			'email' => isset($_POST['email']) && !empty($_POST['email']) ? $_POST['email'] : '',
			'country_code' => isset($_POST['country_code']) && !empty($_POST['country_code']) ? $_POST['country_code'] : '',
			'phone' => isset($_POST['phone']) && !empty($_POST['phone']) ? $_POST['phone'] : '',
			'address' => isset($_POST['address']) && !empty($_POST['address']) ? $_POST['address'] : '',
			'gender' => isset($_POST['gender']) && !empty($_POST['gender']) ? $_POST['gender'] : '',
			'hobby' => isset($_POST['hobby']) && !empty($_POST['hobby']) ? implode(",",$_POST['hobby']) : '',
			// 'photo' => isset($_POST['photo']) && !empty($_POST['photo']) ? implode(",",$_POST['photo']) : '',
		);
		$id = isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : '';

		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'jpg|jpeg|png';
		$this->load->library('upload',$config);
		 
		
		if($this->upload->do_upload('photo')){
			$photoData=$this->upload->data();
			$employee['photo'] = $photoData['file_name'];
		}else{
			$photoName = isset($_POST['photoname']) && !empty($_POST['photoname']) ? $_POST['photoname'] : '';
			$employee['photo'] = $photoName;
		}

		$query = $this->Crudmodel->Upatedata($id,$employee);
		if($query){
			redirect(base_url());
		}
	}
	public function delete(){
	
		$id = isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : '';
		$query = $this->Crudmodel->Deletedata($id);
		if($query){
			redirect(base_url());
		}
	}
}
