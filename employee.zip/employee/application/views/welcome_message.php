<?php
// var_dump($record);
// die;
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</head>
<body>

<div id="container">
	<a href="index.php/welcome/create"><button class="btn btn-primary m-5">Create</button></a>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Profile Photo</th>
      <th scope="col">Full Name</th>
      <th scope="col">Email</th>
      <th scope="col">Phone</th>
      <th scope="col">Address</th>
      <th scope="col">Gender</th>
      <th scope="col">Hobby</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
	  <?php
	    if(!empty($record)){
			foreach ($record as $key => $value) {
				?>
				   <tr>
					<th scope="row"><?php echo $value->id?></th>
					<td><img src="<?php echo base_url().'uploads/'.$value->photo?>" alt="" height='100' width='100'></td>
					<td><?php echo $value->first_name.' '.$value->last_name?></td>
					<td><?php echo $value->email?></td>
					<td><?php echo $value->country_code.' '.$value->phone?></td>
					<td><?php echo $value->address?></td>
					<td><?php echo $value->gender?></td>
					<td><?php echo $value->hobby?></td>
					<td><a href="index.php/welcome/edit?id=<?php echo $value->id?>"><button class="btn btn-success">Edit</button></a> <a href="index.php/welcome/delete?id=<?php echo $value->id?>"><button class="btn btn-danger ">Delete</button></a></td>
				  </tr>

				<?php
			}
		}
	 ?>
  </tbody>
</table>
	
</div>

</body>
</html>
