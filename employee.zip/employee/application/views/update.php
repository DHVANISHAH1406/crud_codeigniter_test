<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <style>
        .create-form{
            margin: 30px;
            background-color: beige;
            /* color: white; */
            border-style: solid;
            border-radius: 5px;
            padding: 10px;
        }
        .img-class{
            justify-self: center;
        }
    </style>
</head>
<body>

<div id="container">

<form class="create-form" method="POST" action="update" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $record->id?>">
    <h2>Edit Employee</h2>
    <div class="img-class">
        <img src="<?php echo base_url().'uploads/'.$record->photo?>" alt="" style="border-radius: 100px;" width='200' height='200'>
        <input type="file" class="form-control" id="photo" name="photo">
        <input type="hidden" name="photoname" value="<?php echo $record->photo?>">
  </div>
  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="first_name">First Name</label>
      <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $record->first_name?>">
    </div>
    <div class="form-group col-md-3">
    <label for="last_name">Last Name</label>
      <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $record->last_name?>">
    </div>
  </div>
  <div class="form-group">
  <div class="form-group col-md-3">
  <label for="email">Email</label>
      <input type="email" class="form-control" id="email" name="email" value="<?php echo $record->email?>">
    </div>
  </div>
  <div class="form-group">
  <label for="country_code">Phone</label>
  <div class="form-group col-md-9">
        <select name="country_code" id="country_code" class="form-control-sm">
            <option value="+91" <?php echo $record->country_code=='+91' ? 'selected' : ''?>>+91</option>
            <option value="+51" <?php echo $record->country_code=='+51' ? 'selected' : ''?>>+51</option>
            <option value="+1" <?php echo $record->country_code=='+1' ? 'selected' : ''?>>+1</option>
            <option value="+57" <?php echo $record->country_code=='+57' ? 'selected' : ''?>>+57</option>
            <option value="+579" <?php echo $record->country_code=='+579' ? 'selected' : ''?>>+579</option>
        </select>
        <input type="text" class="form-control-sm" id="phone" name="phone" value="<?php echo $record->phone?>">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="address">Address</label>
      <input type="text" class="form-control" id="address" name="address" value="<?php echo $record->address?>">
    </div>
  </div>
  <div class="form-row">
      <label for="gender">Gender</label>
    <div class="form-group col-md-6">
      <input type="radio" class="form-check-input" id="gender" name="gender" value="Male" <?php echo $record->gender=='Male' ? 'checked' : ''?>>Male
      <input type="radio" class="form-check-input" id="gender" name="gender" value="Female" <?php echo $record->gender=='Female' ? 'checked' : ''?>>Female
    </div>
  </div>
  <div class="form-row">
      <label for="hobby">Hobby</label>
    <div class="form-group col-md-6">
        <?php
        $hobby = explode(",",$record->hobby);
        ?>
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Dancing" <?php echo in_array('Dancing',$hobby) ? 'checked' : ''?>>Dancing
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Reading" <?php echo in_array('Reading',$hobby) ? 'checked' : ''?>>Reading
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Study" <?php echo in_array('Study',$hobby) ? 'checked' : ''?>>Study
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Music" <?php echo in_array('Music',$hobby) ? 'checked' : ''?>>Music
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Travelling" <?php echo in_array('Travelling',$hobby) ? 'checked' : ''?>>Travelling
    </div>
  </div>
  <button type="submit" class="btn btn-success mt-3">Edit Employee</button>
  <a href="<?php echo base_url()?>"><button type="submit" class="btn btn-danger mt-3">Cancel</button></a>
</form>
</div>

</body>
</html>
