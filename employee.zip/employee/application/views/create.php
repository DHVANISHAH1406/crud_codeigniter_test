<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <style>
        .create-form{
            margin: 30px;
            background-color: beige;
            /* color: white; */
            border-style: solid;
            border-radius: 5px;
            padding: 10px;
        }
    </style>
</head>
<body>

<div id="container">

<form class="create-form" method="POST" action="insert" enctype="multipart/form-data">
    <h2>Add Employee</h2>
  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="first_name">First Name</label>
      <input type="text" class="form-control" id="first_name" name="first_name">
    </div>
    <div class="form-group col-md-3">
    <label for="last_name">Last Name</label>
      <input type="text" class="form-control" id="last_name" name="last_name">
    </div>
  </div>
  <div class="form-group">
  <div class="form-group col-md-3">
  <label for="email">Email</label>
      <input type="email" class="form-control" id="email" name="email">
    </div>
  </div>
  <div class="form-group">
  <label for="country_code">Phone</label>
  <div class="form-group col-md-9">
        <select name="country_code" id="country_code" class="form-control-sm">
            <option value="+91">+91</option>
            <option value="+51">+51</option>
            <option value="+1">+1</option>
            <option value="+57">+57</option>
            <option value="+579">+579</option>
        </select>
        <input type="text" class="form-control-sm" id="phone" name="phone">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="address">Address</label>
      <input type="text" class="form-control" id="address" name="address">
    </div>
  </div>
  <div class="form-row">
      <label for="gender">Gender</label>
    <div class="form-group col-md-6">
      <input type="radio" class="form-check-input" id="gender" name="gender" value="Male">Male
      <input type="radio" class="form-check-input" id="gender" name="gender" value="Female">Female
    </div>
  </div>
  <div class="form-row">
      <label for="hobby">Hobby</label>
    <div class="form-group col-md-6">
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Dancing">Dancing
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Reading">Reading
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Study">Study
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Music">Music
      <input type="checkbox" class="form-check-input" id="hobby" name="hobby[]" value="Travelling">Travelling
    </div>
  </div>
  <div class="form-row">
      <label for="photo">Photo</label>
    <div class="form-group col-md-6">
      <input type="file" class="form-control" id="photo" name="photo">
    </div>
  </div>
  <button type="submit" class="btn btn-primary mt-3">Add Employee</button>
</form>
</div>

</body>
</html>
