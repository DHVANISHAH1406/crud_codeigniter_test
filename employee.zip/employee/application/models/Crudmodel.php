<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crudmodel extends CI_Model {
	public function Insertdata($employee)
	{
		return $this->db->insert('Employee',$employee);
	}
    public function getData(){
        $record = $this->db->get('Employee');
        if($record->num_rows() > 0){
            return $record->result();
        }
    }
    public function getEmpById($id){
        $record = $this->db->get_where('Employee',['id'=>$id]);
        if($record->num_rows() > 0){
            return $record->row();
        }
    }
    public function Upatedata($id,$employee)
	{
        $this->db->where('Employee.id',$id);
		return $this->db->update('Employee',$employee);
	}
    public function Deletedata($id)
	{
        $this->db->where('Employee.id',$id);
		return $this->db->delete('Employee');
	}
}
